package com.eteration.simplebanking.services;


import com.eteration.simplebanking.model.Account;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

// This class is a place holder you can change the complete implementation
@Service
public class AccountService {


    public Account findAccount(String accountId) {
        return null;
    }
}
